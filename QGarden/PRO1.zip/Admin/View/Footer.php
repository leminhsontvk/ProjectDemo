<?php
/** Check Access **/
if (!defined('QGAccessGrained')) {header("HTTP/2 404 Not Found"); exit();}
?>

<div class="container">
    <footer style="min-height: unset;" class="margin-top-20 padding-top-20">
        <div class="clearfix"></div>
        <div class="copyright">
            <p>Copyright © <span id="Year"></span> <a href="<?=$PublicConfig::WebDocumentRoot?>">QGarden - LMSQ Group</a>. All Right Reserved.</p>
        </div>
    </footer>
</div>
</div>
